# REPO_RPC

Discord Rich Presence support for R.E.P.O.

It's a fork of [R.E.P.O Discord Presence](https://github.com/Toliann/REPO-Discord-Rich-Presence) by [Toliann](https://github.com/Toliann)

## Installation

Install via [r2modman](https://thunderstore.io/c/repo/p/Tubix/REPO_RPC/)

 or 

Download the mod >>> Place the mod in "REPO/BeplnEx/plugins/"

![Screenshot1](https://github.com/user-attachments/assets/a93acce3-3543-482a-8e85-76a7151997f4)


## Credits

Thanks to [Andrey Mrovol](https://github.com/AndreyMrovol) for the original code base of [LethalRichPresence](https://github.com/AndreyMrovol/LethalRichPresence) - [MIT License](https://github.com/AndreyMrovol/LethalRichPresence/blob/main/LICENSE), which was a major inspiration and foundation for this mod.

Thanks to [Lachee](https://github.com/Lachee/discord-rpc-csharp) for the DiscordRPC.dll

Thanks to [Toliann](https://github.com/Toliann) for the original project ^^

### My discord - Tubix
- My discord server - [Tubix Server](https://discord.gg/8SRNkCGDjk)
