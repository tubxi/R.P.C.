- 0.1.6 Rebuild

- 0.1.5 disabled config(temporarily), added level pictures

- 0.1.4 Fixed initialisation

- 0.1.3 Fixed problem with ‘waiting for players’ when you are on a level

- 0.1.2 Stabilisation

- 0.1.1 DiscordRPC updated

- 0.1.0 Release 