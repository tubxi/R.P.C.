- 0.1.1 DiscordRPC updated

- 0.1.0 Release 