# R.E.P.O Discord Presence

Discord Rich Presence support for R.E.P.O.

At the moment this is the first version. in the future will be expanded the functionality of the mod


## Installation

Install via [r2modman](https://thunderstore.io/c/repo/p/ebkr/r2modman/) or [Gale](https://thunderstore.io/c/lethal-company/p/Kesomannen/GaleModManager/)

 or 

download the mod >>> BeplnEx>plugins>

![Screenshot1](https://raw.githubusercontent.com/Toliann/REPO-Discord-Rich-Presence/refs/heads/main/Screenshot/1.png?token=GHSAT0AAAAAACV3UMX4TA623WG7ZNSIV3DIZ6TATJQ)


## Credits

Thanks to [Grimgar](https://www.youtube.com/channel/UCPLRVtdWzuBcTAqssRfUa5g) for creating the mod icon

Thanks to [Andrey Mrovol](https://github.com/AndreyMrovol) for the original code base of [LethalRichPresence](https://github.com/AndreyMrovol/LethalRichPresence) - [MIT License](https://github.com/AndreyMrovol/LethalRichPresence/blob/main/LICENSE), which was a major inspiration and foundation for this mod.

Thanks to [Lachee](https://github.com/Lachee/discord-rpc-csharp) for the DiscordRPC.dll